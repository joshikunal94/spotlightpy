'''	Use the sub module spotlight to harness Images from MS Windows X Spotlight project'''

from spotlightpy import spotlight

